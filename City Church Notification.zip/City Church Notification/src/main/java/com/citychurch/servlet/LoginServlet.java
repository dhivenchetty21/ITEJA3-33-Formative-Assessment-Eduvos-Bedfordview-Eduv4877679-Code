package com.citychurch.servlet;

import com.citychurch.model.User;
import com.citychurch.store.UserStore;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
Login Servlet
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //read the form fields
        String username = trim(request.getParameter("username"));
        String password = trim(request.getParameter("password"));

        //validation: nothing may be empty
        if (isEmpty(username) || isEmpty(password)) {
            fail(request, response, "Username and password are required.");
            return;
        }

        // Validate the credentials against the in-memory store
        User user = UserStore.authenticate(username, password);
        if (user == null) {
            fail(request, response, "Invalid username or password.");
            return;
        }

        //create an HTTP session and store the authenticated user
        HttpSession session = request.getSession(true);
        session.setAttribute("user", user);
        session.setMaxInactiveInterval(30 * 60); // 30 minutes

        //success response: send the user to the home page
        response.sendRedirect(request.getContextPath() + "/home.jsp");
    }

    private void fail(HttpServletRequest request, HttpServletResponse response, String message)
            throws ServletException, IOException {
        request.setAttribute("error", message);
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    private static boolean isEmpty(String s) {
        return s == null || s.isEmpty();
    }

    private static String trim(String s) {
        return s == null ? null : s.trim();
    }
}
