package com.citychurch.servlet;

import com.citychurch.model.User;
import com.citychurch.store.UserStore;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
User Registration Servlet.
 */
@WebServlet(name = "RegisterServlet", urlPatterns = {"/register"})
public class RegisterServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //read the form fields
        String username = trim(request.getParameter("username"));
        String password = trim(request.getParameter("password"));
        String role = trim(request.getParameter("role"));

        //validation: nothing may be empty
        if (isEmpty(username) || isEmpty(password) || isEmpty(role)) {
            fail(request, response, "All fields are required.");
            return;
        }

        //the role must be one of the two allowed values
        if (!"LEADER".equalsIgnoreCase(role) && !"MEMBER".equalsIgnoreCase(role)) {
            fail(request, response, "Please select a valid role.");
            return;
        }

        //reject duplicate usernames
        if (UserStore.exists(username)) {
            fail(request, response, "Username '" + username + "' is already taken.");
            return;
        }

        //store the new user in memory
        boolean added = UserStore.addUser(new User(username, password, role.toUpperCase()));

        //success / error response
        if (added) {
            // Redirect to the login page with a success flag.
            response.sendRedirect(request.getContextPath()
                    + "/login.jsp?registered=1&username="
                    + java.net.URLEncoder.encode(username, "UTF-8"));
        } else {
            fail(request, response, "Registration failed. Please try again.");
        }
    }

    /** Forward back to the registration form showing an error message. */
    private void fail(HttpServletRequest request, HttpServletResponse response, String message)
            throws ServletException, IOException {
        request.setAttribute("error", message);
        request.getRequestDispatcher("/registration.jsp").forward(request, response);
    }

    private static boolean isEmpty(String s) {
        return s == null || s.isEmpty();
    }

    private static String trim(String s) {
        return s == null ? null : s.trim();
    }
}
