package com.citychurch.websocket;

import com.citychurch.jms.NotificationSender;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.inject.Inject;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

/**WebSocket Endpoint for Messaging.
Integration with WebSockets.
 */
@ServerEndpoint("/notify")
public class NotificationEndpoint {

    /** Thread-safe set of all currently open WebSocket sessions. */
    private static final Set<Session> SESSIONS =
            Collections.newSetFromMap(new ConcurrentHashMap<Session, Boolean>());

    /**In-memory history of every notification broadcast so far
     */
    private static final List<String> HISTORY = new CopyOnWriteArrayList<>();
    private static final int MAX_HISTORY = 100;

    /**Injected EJB that publishes messages to the JMS topic.
     */
    @Inject
    private NotificationSender notificationSender;

    @OnOpen
    public void onOpen(Session session) {
        SESSIONS.add(session);
        System.out.println("WebSocket opened: " + session.getId()
                + " (total: " + SESSIONS.size() + ")");

        // Catch this client up on notifications it missed (e.g. sent while
        // the member was logged out, or before they navigated to the page).
        for (String pastMessage : HISTORY) {
            try {
                session.getBasicRemote().sendText(pastMessage);
            } catch (IOException ex) {
                System.err.println("Failed to replay history to " + session.getId()
                        + ": " + ex.getMessage());
                break;
            }
        }
    }

    @OnClose
    public void onClose(Session session) {
        SESSIONS.remove(session);
        System.out.println("WebSocket closed: " + session.getId()
                + " (total: " + SESSIONS.size() + ")");
    }

    /**Called when a leader submits a notification from the browser.
     */
    @OnMessage
    public void onMessage(String message, Session session) {
        System.out.println("Received from client " + session.getId() + ": " + message);
        if (message != null && !message.trim().isEmpty()) {
            notificationSender.send(message.trim());
        }
    }

    @OnError
    public void onError(Session session, Throwable error) {
        System.err.println("WebSocket error on " + session.getId() + ": " + error.getMessage());
        SESSIONS.remove(session);
    }

    /**Broadcasts a notification to every connected client.
     */
    public static void broadcastMessage(String message) {
        HISTORY.add(message);
        while (HISTORY.size() > MAX_HISTORY) {
            HISTORY.remove(0);
        }
        for (Session session : SESSIONS) {
            if (session.isOpen()) {
                try {
                    session.getBasicRemote().sendText(message);
                } catch (IOException ex) {
                    System.err.println("Failed to send to " + session.getId()
                            + ": " + ex.getMessage());
                }
            }
        }
    }
}
