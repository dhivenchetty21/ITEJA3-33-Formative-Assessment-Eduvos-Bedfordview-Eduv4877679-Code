package com.citychurch.store;

import com.citychurch.model.User;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory user store
 */
public final class UserStore {

    /** username -> User */
    private static final Map<String, User> USERS = new ConcurrentHashMap<>();

    // Test Accounts
    static {
        USERS.put("leader", new User("leader", "leader123", "LEADER"));
        USERS.put("member", new User("member", "member123", "MEMBER"));
    }

    private UserStore() {
        // utility class - no instances
    }

    /** Returns true if a user with this username already exists (Q1.4). */
    public static boolean exists(String username) {
        return username != null && USERS.containsKey(username);
    }

    /**Registers a new user (Q1.3, Q1.4).
     * @return true if added, false if the username was already taken.
     */
    public static synchronized boolean addUser(User user) {
        if (user == null || exists(user.getUsername())) {
            return false;
        }
        USERS.put(user.getUsername(), user);
        return true;
    }

    /**Validates a login attempt
     * @return the matching User on success, or null if the credentials are wrong.
     */
    public static User authenticate(String username, String password) {
        User user = USERS.get(username);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }

    public static User getUser(String username) {
        return USERS.get(username);
    }
}
