package com.citychurch.jms;

import com.citychurch.websocket.NotificationEndpoint;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

/**
 Integration with WebSockets.
 Leader -> WebSocket.onMessage -> JMS topic -> [this MDB] -> WebSocket broadcast -> all clients
 */
@MessageDriven(activationConfig = {
    @ActivationConfigProperty(propertyName = "destinationLookup",
                              propertyValue = "java:app/jms/notificationTopic"),
    @ActivationConfigProperty(propertyName = "destinationType",
                              propertyValue = "javax.jms.Topic")
})
public class NotificationReceiver implements MessageListener {

    @Override
    public void onMessage(Message message) {
        try {
            if (message instanceof TextMessage) {
                String text = ((TextMessage) message).getText();
                System.out.println("MDB received from JMS: " + text);

                // Broadcast the notification to all connected WebSocket clients.
                NotificationEndpoint.broadcastMessage(text);
            }
        } catch (JMSException ex) {
            System.err.println("Error reading JMS message: " + ex.getMessage());
        }
    }
}
