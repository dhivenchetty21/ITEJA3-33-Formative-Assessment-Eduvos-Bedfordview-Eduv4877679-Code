package com.citychurch.jms;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jms.JMSConnectionFactory;
import javax.jms.JMSConnectionFactoryDefinition;
import javax.jms.JMSContext;
import javax.jms.JMSDestinationDefinition;
import javax.jms.Topic;

/**
JMS Configuration.
 */
@JMSConnectionFactoryDefinition(
        name = "java:app/jms/notificationFactory",
        description = "Connection factory for City Church notifications"
)
@JMSDestinationDefinition(
        name = "java:app/jms/notificationTopic",
        interfaceName = "javax.jms.Topic",
        destinationName = "CityChurchNotificationTopic",
        description = "Topic that stores/relays church notifications"
)
@Stateless
public class NotificationSender {

    /** JMSContext bound to the connection factory defined above. */
    @Inject
    @JMSConnectionFactory("java:app/jms/notificationFactory")
    private JMSContext jmsContext;

    /** The topic where notifications are published. */
    @Resource(lookup = "java:app/jms/notificationTopic")
    private Topic notificationTopic;

    /**Publishes a notification onto the JMS topic
     */
    public void send(String message) {
        jmsContext.createProducer().send(notificationTopic, message);
        System.out.println("Published to JMS topic: " + message);
    }
}
