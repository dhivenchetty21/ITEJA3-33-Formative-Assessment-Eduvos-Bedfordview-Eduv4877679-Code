<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%--  Registration page --%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>City Church Notification System - Registration</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="card">
    <div class="top-bar"></div>
    <div class="content">
        <h1>City Church Notification System</h1>
        <h2>Registration</h2>

        <%-- Error message forwarded by the RegisterServlet --%>
        <% if (request.getAttribute("error") != null) { %>
            <p class="error"><%= request.getAttribute("error") %></p>
        <% } %>

        <form action="register" method="post" class="form">
            <input type="text" name="username" placeholder="Username" required />
            <input type="password" name="password" placeholder="Password" required />
            <%-- Role lets you test role-based access control
                 In a production system members would not choose their own role. --%>
            <select name="role" class="select">
                <option value="MEMBER">Member</option>
                <option value="LEADER">Church Leader</option>
            </select>
            <button type="submit" class="btn">Register</button>
        </form>

        <a href="login.jsp"><button type="button" class="btn-outline">Back to Login</button></a>
    </div>
</div>
</body>
</html>
