<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.citychurch.model.User" %>
<%--
Notification page with ROLE-BASED ACCESS CONTROL.
    Only authenticated users whose role is LEADER may reach this page.
    Members (or anyone not logged in) are redirected away.
--%>
<%
    User currentUser = (session != null) ? (User) session.getAttribute("user") : null;

    // Not logged in -> back to login.
    if (currentUser == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    // Logged in but NOT a leader -> access denied, back to home.
    if (!currentUser.isLeader()) {
        response.sendRedirect(request.getContextPath() + "/home.jsp?denied=1");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>City Church Notification System - Server Side</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="card">
    <div class="top-bar"></div>
    <div class="content">
        <h1>City Church Notification System</h1>
        <h2>Server - side</h2>

        <label class="label">Write a notification to send to the church members</label>
        <textarea id="message" class="textarea" rows="4"
                  placeholder="e.g. Youth Sunday - 9 December 2026"></textarea>
        <button type="button" class="btn" onclick="sendNotification()">Send notification</button>

        <h3>Live feed</h3>
        <div id="notifications" class="notification-box">
            <p class="muted">Sent notifications will appear here.</p>
        </div>

        <a href="home.jsp"><button type="button" class="btn-outline">Back to Home</button></a>
    </div>
</div>

<script>
    var contextPath = "<%= request.getContextPath() %>";
    var protocol = (window.location.protocol === "https:") ? "wss://" : "ws://";
    var socket = new WebSocket(protocol + window.location.host + contextPath + "/notify");
    var box = document.getElementById("notifications");
    var first = true;

    // Incoming notifications (relayed from JMS) are shown here too.
    socket.onmessage = function (event) {
        if (first) { box.innerHTML = ""; first = false; }
        var item = document.createElement("div");
        item.className = "notification-item";
        item.textContent = event.data;
        box.appendChild(item);
    };

    // Send the leader's message over the WebSocket. The server routes it
    // through JMS and then broadcasts it back to every connected client.
    function sendNotification() {
        var text = document.getElementById("message").value.trim();
        if (text === "") { return; }
        socket.send(text);
        document.getElementById("message").value = "";
    }
</script>
</body>
</html>
