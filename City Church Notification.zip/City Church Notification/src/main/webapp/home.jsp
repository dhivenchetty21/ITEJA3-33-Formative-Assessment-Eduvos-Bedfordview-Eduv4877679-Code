<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="com.citychurch.model.User" %>

<%
    // Basic session guard: only logged-in users may see this page.
    User currentUser = (session != null) ? (User) session.getAttribute("user") : null;
    if (currentUser == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
%>
<!DOCTYPE html>

<html>
<head>
    <meta charset="UTF-8">
    <title>City Church - Home</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="card">
    <div class="top-bar"></div>
    <div class="content">
        <h1>City Church</h1>
        <h2>Home</h2>
        <p class="welcome">Welcome, <b><%= currentUser.getUsername() %></b>
            (<%= currentUser.getRole() %>)</p>

        <h3>Notifications</h3>
        <div id="notifications" class="notification-box">
            <p class="muted">Waiting for announcements...</p>
        </div>

        <%-- Only Church Leaders see the link to the send/manage page (Q10). --%>
        <% if (currentUser.isLeader()) { %>
            <a href="notification.jsp"><button type="button" class="btn">Send a Notification</button></a>
        <% } %>

        <a href="logout"><button type="button" class="btn-outline">Logout</button></a>
    </div>
</div>

<script>
    // Open a receive-only WebSocket so this page shows notifications live.
    var contextPath = "<%= request.getContextPath() %>";
    var protocol = (window.location.protocol === "https:") ? "wss://" : "ws://";
    var socket = new WebSocket(protocol + window.location.host + contextPath + "/notify");
    var box = document.getElementById("notifications");
    var first = true;

    socket.onmessage = function (event) {
        if (first) { box.innerHTML = ""; first = false; }
        var item = document.createElement("div");
        item.className = "notification-item";
        item.textContent = event.data;
        box.appendChild(item);
    };
    socket.onclose = function () {
        console.log("Notification socket closed.");
    };
</script>
</body>
</html>
