<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%-- Login page --%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>City Church Notification System - Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="card">
    <div class="top-bar"></div>
    <div class="content">
        <h1>City Church Notification System</h1>
        <h2>Login</h2>

        <%-- Show a success message after registration --%>
        <% if ("1".equals(request.getParameter("registered"))) { %>
            <p class="success">Registration successful. Please log in.</p>
        <% } %>

        <%-- Show an error message forwarded by the LoginServlet --%>
        <% if (request.getAttribute("error") != null) { %>
            <p class="error"><%= request.getAttribute("error") %></p>
        <% } %>

        <form action="login" method="post" class="form">
            <input type="text" name="username" placeholder="Username"
                   value="<%= request.getParameter("username") == null ? "" : request.getParameter("username") %>"
                   required />
            <input type="password" name="password" placeholder="Password" required />
            <button type="submit" class="btn">Login</button>
        </form>

        <a href="registration.jsp"><button type="button" class="btn">Register</button></a>
    </div>
</div>
</body>
</html>
