# City Church Notification System

A Java EE 8 web application implementing the ITEJA3-33 practical assignment:
Servlets for registration/login, a WebSocket endpoint for real-time notifications,
and JMS (topic + message-driven bean) for reliable message delivery. User profiles
and messages are held **in memory** as the brief requires.

## What maps to what (marking guide)

| Deliverable | Requirement | File(s) |
|---|---|---|
| D1 Q1 | Registration servlet (in-memory, duplicate check) | `servlet/RegisterServlet.java`, `store/UserStore.java` |
| D1 Q2 | Login servlet (HTTP session) | `servlet/LoginServlet.java` |
| D1 Q3 | WebSocket `@ServerEndpoint` (onOpen/onClose/broadcast) | `websocket/NotificationEndpoint.java` |
| D1 Q4 | JMS connection factory + destination (topic) | `jms/NotificationSender.java` |
| D1 Q5 | JMS notification broadcast to WebSocket clients | `jms/NotificationReceiver.java` (MDB) |
| D1 Q6 | User class | `model/User.java` |
| D2 Q7 | login.jsp | `webapp/login.jsp` |
| D2 Q8 | registration.jsp | `webapp/registration.jsp` |
| D2 Q9 | home.jsp (view notifications) | `webapp/home.jsp` |
| D2 Q10 | notification.jsp with role-based access control | `webapp/notification.jsp` |

## How it fits together

```
Leader types announcement (notification.jsp)
        |  WebSocket.send()
        v
NotificationEndpoint.onMessage()  --publish-->  JMS Topic
        (reliable delivery / persistence)          |
                                                    v
                                      NotificationReceiver (MDB) consumes
                                                    |
                                                    v
                            NotificationEndpoint.broadcastMessage()
                                                    |
                                     pushes to ALL connected browsers
                                                    v
                              home.jsp / notification.jsp show it live
```

## Requirements

- **JDK 8**
- **GlassFish 5.0 or 5.1** (Full Platform — needed for JMS + WebSocket + Servlets)
- **NetBeans** (any recent version with the Maven and GlassFish plugins)

This project uses the `javax.*` namespace (Java EE 8). See "GlassFish 6/7" below
if your server is newer.

## Running it in NetBeans

1. Start NetBeans → **File → Open Project** → select the `CityChurchNotification`
   folder. It is recognised as a Maven project automatically (no `nbproject`
   files needed).
2. Register your GlassFish server if you have not already:
   **Services → Servers → right-click → Add Server → GlassFish**, then point it
   at your GlassFish install.
3. Right-click the project → **Properties → Run** and set **Server** to GlassFish
   (and Context Path `/CityChurchNotification`).
4. Right-click the project → **Run**. NetBeans builds the WAR, deploys it, and
   opens the browser.
5. Browse to: `http://localhost:8080/CityChurchNotification/`

### Test accounts (pre-seeded, see `UserStore.java`)

| Username | Password | Role |
|---|---|---|
| `leader` | `leader123` | LEADER |
| `member` | `member123` | MEMBER |

You can also register new users; choose the **Church Leader** role to test that
only leaders can open `notification.jsp`.

### Quick demo

1. Log in as `leader` in one browser tab, open **Send a Notification**.
2. Log in as `member` in a second tab/browser → stay on **Home**.
3. Type a message as the leader and click **Send notification**.
4. It appears live on the member's Home page (via JMS → MDB → WebSocket).
5. Try opening `.../CityChurchNotification/notification.jsp` while logged in as
   `member` — you are redirected away (role-based access control).

## Building the WAR without the IDE (optional)

```bash
mvn clean package
# produces target/CityChurchNotification.war  -> deploy to GlassFish
```

## Troubleshooting

- **`@Inject` in the WebSocket fails** — make sure `WEB-INF/beans.xml` is present
  (it is) so CDI is active.
- **MDB does not receive messages / topic not found** — the JMS resources are
  created automatically by the annotations in `NotificationSender.java`. If your
  GlassFish blocks that, create them manually in the admin console
  (`http://localhost:4848`): a Connection Factory named
  `java:app/jms/notificationFactory` and a JMS **Topic** destination named
  `CityChurchNotificationTopic`, then redeploy.
- **Use the GlassFish "Full Platform"**, not the Web Profile — the Web Profile
  omits JMS.

## GlassFish 6 / 7 (Jakarta EE 9+)

Those servers use the `jakarta.*` namespace instead of `javax.*`. To target them:

1. In `pom.xml` swap the dependency for
   `jakarta.platform:jakarta.jakartaee-api:8.0.0` (EE 8, still `javax`) — **or**
   `10.0.0` for full Jakarta EE 10.
2. If you move to EE 9+/10, find-and-replace `javax.` → `jakarta.` across the
   Java imports and update the `web.xml` / `beans.xml` schema URLs to the
   `jakarta` namespaces.

For a standard GlassFish 5 lab setup, no changes are needed.
